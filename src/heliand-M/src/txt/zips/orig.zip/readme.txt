# Heliand-M    

ms. Monacensis (codex)
	- source: https://handschriftencensus.de/8827
	- text: https://www.lwl.org/331-download/niw/html/40001B.html, cf. https://www.niederdeutsch-in-westfalen.de/de/texte/religion/a/
	- translation (Koene 1855, with supplements from C): http://www.lwl.org/331-download/Texte/html/40001Ct.html
	- syntax: none

annotations:
- annotation projection from German?
- parse with Heliand parser
- project annotations from Heliand-BT