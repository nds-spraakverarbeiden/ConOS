# CoNLL conversion of the B4 Heliand corpus

Note that this 3.500 tokens only, i.e., about 5% of the full corpus, as training data, this is neglectable, but it can be used for testing.

## Content

- `zips/paula_1-0.zip` original source data as provided by [Laudatio][https://www.laudatio-repository.org/browse/corpus/7ySuCXMB7CArCQ9Ccica/corpora)
- `b4-conll/` CoNLL/TSV edition of the original PAULA data
- `conll/` consolidated CoNLL annotation

## CoNLL/TSV edition (results in `b4-conll/`)

We provide an opportunistic* converter from Heliand PAULA to CoNLL. Run with 

	$> ./scripts/paula2conll.sh
	
This will create `tmp/paula/b4.heliand/*/*.merged.conll`. The _manually curated_ form of these files resides under `b4_conll/`.
	
Based on the PAULA data model, we generate the following column structure:

0      ID (numerical token identifier)
1      TOKEN (original token identifier)
2      WORD (string value, draw from comment [!] in *.tok.xml)
3      segmentation (with annotation-specific column label)
       annotation-specific segmentation in IOBES format, corresponding to one PAULA *Seg.xml file, e.g., "aboutness" (for *aboutnessSeg.xml)
       note that the labels provided are identifiers (i.e. unique within the column), but not meaningful
4..n   annotation (with annotation-specific column label)
       one or multiple columns with annotations of the segments defined in 3, each corresponding to one PAULA *Seg_*.xml file.
       the annotation is attached to the first element of the corresponding segment.
       column label is a concatenation of segmentation label (see 3) and feature name, e.g., "aboutness:aboutness" (for *aboutnessSeg_aboutness.xml)
n+1    analoguous to 3
n+2..m analoguous to 4
       etc.

The order of columns 3 and following is determined by the lexicographical order of the underlying files.
This structure can be substantially simplified, esp. for annotations for individual tokens, but this needs to be verified by hand.
In particular, the sequence, content, position and existence of columns is defined by the PAULA files provided, and these are not necessarily the same 
across different subcorpora.

* Note that this is specific to this data, no guarantees for functionality on other data sets.
In particular, we rely on resource-specific conventions for file naming, layout, attribute and element order, XML comments (!) and the structure of xpointers.
Further, we only support data structures encountered here, no support for structs or feature groups.
It is expected, however, that this may be applicable to other Exmaralda-based PAULA data provided by HU Berlin or U Potsdam.

## Consolidated CoNLL/TSV edition (results in `conll/`)

Generated from `b4-conll/`, compact aggregation of PAULA data structures into one column per *Seg.xml, conversion to PTB-style syntax annotation. Resulting column structure:

	ID WORD PARSE aboutness alliteration bibl context definiteness bg marker givenness position no comm marker trans

Here, `PARSE` combines the annotations of 8 original B4-CoNLL columns ("cat", "cat:cat", "clause", "clause:status", "gf", "gf:gf", "pos", "pos:pos").
Created using

	$> cat $b4file.conll | python3 consolidate-b4.py > $outfile.conll

## Attribution

Source data under

CC BY 3.0
Svetlana Petrova, Karin Donhauser, Sonja Linde; Heliand; Humboldt-Universität zu Berlin
https://www.sfb632.uni-potsdam.de/aprojekte/b4.html.

Attribution for CoNLL editions to be provided.

## History

- 1935 print edition (soure tbc.)
- 2015 PAULA edition [B4]
- 2020-07-21 CoNLL (`b4-conll`) edition [CC]
- 2021-06-07 CoNLL-U edition [CC]

## Contributors

- B4 - Svetlana Petrova, Karin Donhauser, Sonja Linde, https://www.sfb632.uni-potsdam.de/aprojekte/b4.html
- CC - chiarcos@cs.uni-frankfurt.de